# FOUNDRY by Sun — Concrete & Silver asset package

Owner approved the concrete/silver foundation-block F direction on 2026-11-17.
Tagline: Build. Standardize. Launch.

## Installation

Package layout follows SUN Ecosystem PRODUCT-BRANDING.md section 8 and Foundry docs/BRANDING-ZIP-INSTALLER.md. Upload this ZIP under its original filename in branding/revisions/ using the documented feature-branch workflow where adopted, or the documented manual Preview / Apply fallback. Do not name the upload v1.zip or v2.zip: revision numbers are assigned by the installer.

Required assets: panoramic readme-banner.png (1536 × 576); square transparent symbol.png (1280 × 1280); nine icons at 16, 24, 32, 48, 64, 128, 256, 512 and 1024 pixels.

## Provenance and export

The banner is the unscaled top panel, crop rectangle (0,0,1536,576), of the approved board. The complete approved board is preserved byte-for-byte under branding/assets/refs/approved-concrete-silver-board.png. Its word CONCEPT is historical review-sheet text; the owner subsequently finalized this direction.

The transparent symbol is an image-assisted adaptation using the approved top-banner mark as reference, not a pixel-exact cutout or layered original. It retains pale concrete blocks, brushed silver beams, golden joint light and the SUN arc. All icons are Lanczos resizes of this one RGBA master, with identical framing and no separate optical redraws. Fine texture and the thin arc diminish at tiny sizes; inspect PREVIEW.png and actual 16–32 px exports in the target UI before merging.

Exact recreation of the artwork typography is not provided; the banner retains its approved rendered lettering. Suggested sampled/working color roles: navy #081631, pale concrete #D8CCB8, silver #D2D1CE, warm sunlight #FFB333. These are reference values, not a separate palette redesign.

Preserve proportions and clear space. Prefer dark backdrops for tiny silver marks. No SVG, ICO or theme/monochrome adaptations are included because the installer accepts PNG artwork. Additional platform exports can follow specific application needs.

## Repository adoption

The installer changes asset files only. In the installation PR, update the product brand guide to record this approved direction and provenance; verify the README uses the stable banner path and export configuration uses symbol.png. Preserve existing legacy archives. Root README.md, manifest.json and PREVIEW.png are informational and ignored by the installer. No repository has been modified by preparation of this package.
